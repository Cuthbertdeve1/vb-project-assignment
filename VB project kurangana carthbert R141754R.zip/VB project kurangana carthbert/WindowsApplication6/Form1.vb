﻿Public Class Form1
    Private Sub btnUserlogin_Click(sender As Object, e As EventArgs) Handles btnUserlogin.Click

        frmuserlogin.Show()



    End Sub

    Private Sub btnUserregister_Click(sender As Object, e As EventArgs) Handles btnUserregister.Click
        frmUserRegistare.Show()

    End Sub

    Private Sub btnuserexit_Click(sender As Object, e As EventArgs) Handles btnuserexit.Click
        Me.Close()
    End Sub

    Private Sub btnAdexit_Click(sender As Object, e As EventArgs) Handles btnAdexit.Click
        Me.Close()
    End Sub

    Private Sub btnAdlogin_Click(sender As Object, e As EventArgs) Handles btnAdlogin.Click
        If txtAdusername.Text = "vert" And txtAdpassword.Text = "adminpass" Then
            frmAdiminLogin.Show()
        Else
            MsgBox("please enter correct details")
        End If
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class
