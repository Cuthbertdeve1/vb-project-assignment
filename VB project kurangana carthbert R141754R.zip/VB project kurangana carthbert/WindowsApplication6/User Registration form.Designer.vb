﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmUserRegistare
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnregistar = New System.Windows.Forms.Button()
        Me.btnexit = New System.Windows.Forms.Button()
        Me.combAnimal = New System.Windows.Forms.ComboBox()
        Me.grpsex = New System.Windows.Forms.GroupBox()
        Me.radfemale = New System.Windows.Forms.RadioButton()
        Me.radmale = New System.Windows.Forms.RadioButton()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtname = New System.Windows.Forms.TextBox()
        Me.txtusername = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtpassword = New System.Windows.Forms.TextBox()
        Me.txtrepassword = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtemail = New System.Windows.Forms.TextBox()
        Me.dtpDOB = New System.Windows.Forms.DateTimePicker()
        Me.grpOption = New System.Windows.Forms.GroupBox()
        Me.chkttreatment = New System.Windows.Forms.CheckBox()
        Me.chkbathing = New System.Windows.Forms.CheckBox()
        Me.chkdosing = New System.Windows.Forms.CheckBox()
        Me.chktraining = New System.Windows.Forms.CheckBox()
        Me.chkfeeding = New System.Windows.Forms.CheckBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.grpsex.SuspendLayout()
        Me.grpOption.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnregistar
        '
        Me.btnregistar.Location = New System.Drawing.Point(52, 279)
        Me.btnregistar.Name = "btnregistar"
        Me.btnregistar.Size = New System.Drawing.Size(75, 23)
        Me.btnregistar.TabIndex = 0
        Me.btnregistar.Text = "Register"
        Me.btnregistar.UseVisualStyleBackColor = True
        '
        'btnexit
        '
        Me.btnexit.Location = New System.Drawing.Point(258, 279)
        Me.btnexit.Name = "btnexit"
        Me.btnexit.Size = New System.Drawing.Size(75, 23)
        Me.btnexit.TabIndex = 1
        Me.btnexit.Text = "clear"
        Me.btnexit.UseVisualStyleBackColor = True
        '
        'combAnimal
        '
        Me.combAnimal.FormattingEnabled = True
        Me.combAnimal.Items.AddRange(New Object() {"Dogs", "Cats", "Cattle", "Fishs", "Birds", ""})
        Me.combAnimal.Location = New System.Drawing.Point(340, 38)
        Me.combAnimal.Name = "combAnimal"
        Me.combAnimal.Size = New System.Drawing.Size(121, 21)
        Me.combAnimal.TabIndex = 3
        Me.combAnimal.Text = "animals"
        '
        'grpsex
        '
        Me.grpsex.Controls.Add(Me.radfemale)
        Me.grpsex.Controls.Add(Me.radmale)
        Me.grpsex.Location = New System.Drawing.Point(27, 151)
        Me.grpsex.Name = "grpsex"
        Me.grpsex.Size = New System.Drawing.Size(172, 92)
        Me.grpsex.TabIndex = 4
        Me.grpsex.TabStop = False
        Me.grpsex.Text = "Sex"
        '
        'radfemale
        '
        Me.radfemale.AutoSize = True
        Me.radfemale.Location = New System.Drawing.Point(41, 50)
        Me.radfemale.Name = "radfemale"
        Me.radfemale.Size = New System.Drawing.Size(59, 17)
        Me.radfemale.TabIndex = 1
        Me.radfemale.TabStop = True
        Me.radfemale.Text = "Female"
        Me.radfemale.UseVisualStyleBackColor = True
        '
        'radmale
        '
        Me.radmale.AutoSize = True
        Me.radmale.Location = New System.Drawing.Point(41, 27)
        Me.radmale.Name = "radmale"
        Me.radmale.Size = New System.Drawing.Size(48, 17)
        Me.radmale.TabIndex = 0
        Me.radmale.TabStop = True
        Me.radmale.Text = "Male"
        Me.radmale.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(24, 8)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(35, 13)
        Me.Label1.TabIndex = 5
        Me.Label1.Text = "Name"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(12, 38)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(55, 13)
        Me.Label2.TabIndex = 6
        Me.Label2.Text = "Username"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(365, 12)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(65, 13)
        Me.Label3.TabIndex = 7
        Me.Label3.Text = "Animal Tpye"
        '
        'txtname
        '
        Me.txtname.Location = New System.Drawing.Point(92, 5)
        Me.txtname.Name = "txtname"
        Me.txtname.Size = New System.Drawing.Size(138, 20)
        Me.txtname.TabIndex = 8
        '
        'txtusername
        '
        Me.txtusername.Location = New System.Drawing.Point(92, 31)
        Me.txtusername.Name = "txtusername"
        Me.txtusername.Size = New System.Drawing.Size(138, 20)
        Me.txtusername.TabIndex = 9
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(9, 60)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(53, 13)
        Me.Label4.TabIndex = 10
        Me.Label4.Text = "Password"
        '
        'txtpassword
        '
        Me.txtpassword.Location = New System.Drawing.Point(92, 57)
        Me.txtpassword.Name = "txtpassword"
        Me.txtpassword.Size = New System.Drawing.Size(138, 20)
        Me.txtpassword.TabIndex = 11
        '
        'txtrepassword
        '
        Me.txtrepassword.Location = New System.Drawing.Point(92, 80)
        Me.txtrepassword.Name = "txtrepassword"
        Me.txtrepassword.Size = New System.Drawing.Size(138, 20)
        Me.txtrepassword.TabIndex = 12
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(-4, 80)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(90, 13)
        Me.Label5.TabIndex = 13
        Me.Label5.Text = "Retype Password"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(9, 108)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(32, 13)
        Me.Label6.TabIndex = 14
        Me.Label6.Text = "Email"
        '
        'txtemail
        '
        Me.txtemail.Location = New System.Drawing.Point(92, 108)
        Me.txtemail.Name = "txtemail"
        Me.txtemail.Size = New System.Drawing.Size(138, 20)
        Me.txtemail.TabIndex = 15
        '
        'dtpDOB
        '
        Me.dtpDOB.Location = New System.Drawing.Point(249, 236)
        Me.dtpDOB.Name = "dtpDOB"
        Me.dtpDOB.Size = New System.Drawing.Size(200, 20)
        Me.dtpDOB.TabIndex = 17
        '
        'grpOption
        '
        Me.grpOption.Controls.Add(Me.chkfeeding)
        Me.grpOption.Controls.Add(Me.chktraining)
        Me.grpOption.Controls.Add(Me.chkdosing)
        Me.grpOption.Controls.Add(Me.chkbathing)
        Me.grpOption.Controls.Add(Me.chkttreatment)
        Me.grpOption.Location = New System.Drawing.Point(340, 71)
        Me.grpOption.Name = "grpOption"
        Me.grpOption.Size = New System.Drawing.Size(109, 124)
        Me.grpOption.TabIndex = 18
        Me.grpOption.TabStop = False
        Me.grpOption.Text = "Choice Option"
        '
        'chkttreatment
        '
        Me.chkttreatment.AutoSize = True
        Me.chkttreatment.Location = New System.Drawing.Point(9, 19)
        Me.chkttreatment.Name = "chkttreatment"
        Me.chkttreatment.Size = New System.Drawing.Size(74, 17)
        Me.chkttreatment.TabIndex = 0
        Me.chkttreatment.Text = "Treatment"
        Me.chkttreatment.UseVisualStyleBackColor = True
        '
        'chkbathing
        '
        Me.chkbathing.AutoSize = True
        Me.chkbathing.Location = New System.Drawing.Point(9, 41)
        Me.chkbathing.Name = "chkbathing"
        Me.chkbathing.Size = New System.Drawing.Size(62, 17)
        Me.chkbathing.TabIndex = 1
        Me.chkbathing.Text = "Bathing"
        Me.chkbathing.UseVisualStyleBackColor = True
        '
        'chkdosing
        '
        Me.chkdosing.AutoSize = True
        Me.chkdosing.Location = New System.Drawing.Point(9, 64)
        Me.chkdosing.Name = "chkdosing"
        Me.chkdosing.Size = New System.Drawing.Size(59, 17)
        Me.chkdosing.TabIndex = 2
        Me.chkdosing.Text = "Dosing"
        Me.chkdosing.UseVisualStyleBackColor = True
        '
        'chktraining
        '
        Me.chktraining.AutoSize = True
        Me.chktraining.Location = New System.Drawing.Point(6, 87)
        Me.chktraining.Name = "chktraining"
        Me.chktraining.Size = New System.Drawing.Size(64, 17)
        Me.chktraining.TabIndex = 3
        Me.chktraining.Text = "Training"
        Me.chktraining.UseVisualStyleBackColor = True
        '
        'chkfeeding
        '
        Me.chkfeeding.AutoSize = True
        Me.chkfeeding.Location = New System.Drawing.Point(6, 104)
        Me.chkfeeding.Name = "chkfeeding"
        Me.chkfeeding.Size = New System.Drawing.Size(64, 17)
        Me.chkfeeding.TabIndex = 4
        Me.chkfeeding.Text = "Feeding"
        Me.chkfeeding.UseVisualStyleBackColor = True
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(313, 220)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(63, 13)
        Me.Label7.TabIndex = 19
        Me.Label7.Text = "Date ofBirth"
        '
        'frmUserRegistare
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(473, 314)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.grpOption)
        Me.Controls.Add(Me.dtpDOB)
        Me.Controls.Add(Me.txtemail)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.txtrepassword)
        Me.Controls.Add(Me.txtpassword)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.txtusername)
        Me.Controls.Add(Me.txtname)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.grpsex)
        Me.Controls.Add(Me.combAnimal)
        Me.Controls.Add(Me.btnexit)
        Me.Controls.Add(Me.btnregistar)
        Me.Name = "frmUserRegistare"
        Me.Text = "User Registration"
        Me.grpsex.ResumeLayout(False)
        Me.grpsex.PerformLayout()
        Me.grpOption.ResumeLayout(False)
        Me.grpOption.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnregistar As Button
    Friend WithEvents btnexit As Button
    Friend WithEvents combAnimal As ComboBox
    Friend WithEvents grpsex As GroupBox
    Friend WithEvents radfemale As RadioButton
    Friend WithEvents radmale As RadioButton
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents txtname As TextBox
    Friend WithEvents txtusername As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents txtpassword As TextBox
    Friend WithEvents txtrepassword As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents txtemail As TextBox
    Friend WithEvents dtpDOB As DateTimePicker
    Friend WithEvents grpOption As GroupBox
    Friend WithEvents chktraining As CheckBox
    Friend WithEvents chkdosing As CheckBox
    Friend WithEvents chkbathing As CheckBox
    Friend WithEvents chkttreatment As CheckBox
    Friend WithEvents chkfeeding As CheckBox
    Friend WithEvents Label7 As Label
End Class
