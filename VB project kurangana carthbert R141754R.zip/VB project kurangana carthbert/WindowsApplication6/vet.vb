﻿Imports System.Convert
Imports MySql.Data.MySqlClient
Public Module vet
    Public Sub Connection()
        Dim connectionString As String
        Dim vetConn As New MySqlConnection
        connectionString = "server=localhost;userid=root;password=cazzy;database=vertinary_db"
        vetConn.ConnectionString = connectionString
        Try
            vetConn.Open()


        Catch ex As MySqlException
            MsgBox(ex.Message)

        End Try
    End Sub
    Function VetConnection() As MySqlConnection
        Dim connectionString As String
        Dim vetConn As New MySqlConnection
        connectionString = "server=localhost;userid=root;password=cazzy;database=vertinary_db"
        vetConn.ConnectionString = connectionString
        Try
            vetConn.Open()
            MsgBox("connected")
        Catch ex As MySqlException
            MsgBox(ex.Message)

        End Try
        Return vetConn
    End Function
    Public Sub SaveData()

        Dim name As String
        Dim username As String
        Dim password As String
        Dim sex As String
        Dim email As String
        Dim animals As String
        Dim treatment As Boolean
        Dim bathing As Boolean
        Dim dosing As Boolean
        Dim training As Boolean
        Dim dob As String

        Dim cmd As New MySqlCommand
        Dim sqlString As String


        With frmUserRegistare
            name = .txtname.Text
            username = .txtusername.Text
            password = .txtpassword.Text



            If .radmale.Checked Then
                sex = "Male"
            Else
                sex = "Female"
            End If
            email = .txtemail.Text
            If .chkttreatment.Checked Then
                treatment = True
                If .chkbathing.Checked Then
                    bathing = True
                End If
                If .chkdosing.Checked Then
                    dosing = True
                End If
                If .chktraining.Checked Then
                    training = True

                End If


            End If
                animals = .combAnimal.Text

            dob = Format(.dtpDOB.Value, "yyyy-MM-dd")


        End With
        sqlString = "INSERT INTO animal_owner VALUES('" & name & "','" &
            username & "','" & password & "','" & email & "','" & sex & "','" & animals & "'," & treatment & "," & bathing & ",
           " & dosing & "," & training & ",'" & dob & "')"

        With cmd
            .Connection = VetConnection()
            .CommandText = sqlString
            .CommandType = CommandType.Text
            .ExecuteNonQuery()
        End With
        MsgBox("data Saved")

        sqlString = "select * FROM animal_owner ('" & username & "';'" & password & "')"
        With cmd
            .Connection = VetConnection()
            .CommandText = sqlString
            .CommandType = CommandType.Text
            ' .ExecuteNonQuery()
        End With


    End Sub

End Module
