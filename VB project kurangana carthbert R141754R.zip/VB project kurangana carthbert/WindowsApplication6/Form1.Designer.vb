﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.tabAdimn = New System.Windows.Forms.TabPage()
        Me.txtAdpassword = New System.Windows.Forms.TextBox()
        Me.txtAdusername = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.btnAdexit = New System.Windows.Forms.Button()
        Me.btnAdlogin = New System.Windows.Forms.Button()
        Me.tabUser = New System.Windows.Forms.TabPage()
        Me.btnuserexit = New System.Windows.Forms.Button()
        Me.btnUserregister = New System.Windows.Forms.Button()
        Me.btnUserlogin = New System.Windows.Forms.Button()
        Me.tabAdmin = New System.Windows.Forms.TabControl()
        Me.tabAdimn.SuspendLayout()
        Me.tabUser.SuspendLayout()
        Me.tabAdmin.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Monotype Corsiva", 20.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(95, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(221, 33)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Vertinary Hospital "
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'tabAdimn
        '
        Me.tabAdimn.Controls.Add(Me.txtAdpassword)
        Me.tabAdimn.Controls.Add(Me.txtAdusername)
        Me.tabAdimn.Controls.Add(Me.Label3)
        Me.tabAdimn.Controls.Add(Me.Label2)
        Me.tabAdimn.Controls.Add(Me.btnAdexit)
        Me.tabAdimn.Controls.Add(Me.btnAdlogin)
        Me.tabAdimn.Location = New System.Drawing.Point(4, 22)
        Me.tabAdimn.Name = "tabAdimn"
        Me.tabAdimn.Padding = New System.Windows.Forms.Padding(3)
        Me.tabAdimn.Size = New System.Drawing.Size(353, 202)
        Me.tabAdimn.TabIndex = 1
        Me.tabAdimn.Text = "Admin"
        Me.tabAdimn.UseVisualStyleBackColor = True
        '
        'txtAdpassword
        '
        Me.txtAdpassword.Location = New System.Drawing.Point(114, 42)
        Me.txtAdpassword.Name = "txtAdpassword"
        Me.txtAdpassword.Size = New System.Drawing.Size(135, 20)
        Me.txtAdpassword.TabIndex = 11
        '
        'txtAdusername
        '
        Me.txtAdusername.Location = New System.Drawing.Point(114, 12)
        Me.txtAdusername.Name = "txtAdusername"
        Me.txtAdusername.Size = New System.Drawing.Size(135, 20)
        Me.txtAdusername.TabIndex = 10
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(22, 49)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(53, 13)
        Me.Label3.TabIndex = 9
        Me.Label3.Text = "Password"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(18, 15)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(57, 13)
        Me.Label2.TabIndex = 8
        Me.Label2.Text = "UserName"
        '
        'btnAdexit
        '
        Me.btnAdexit.Location = New System.Drawing.Point(174, 91)
        Me.btnAdexit.Name = "btnAdexit"
        Me.btnAdexit.Size = New System.Drawing.Size(75, 23)
        Me.btnAdexit.TabIndex = 7
        Me.btnAdexit.Text = "Exit"
        Me.btnAdexit.UseVisualStyleBackColor = True
        '
        'btnAdlogin
        '
        Me.btnAdlogin.Location = New System.Drawing.Point(93, 91)
        Me.btnAdlogin.Name = "btnAdlogin"
        Me.btnAdlogin.Size = New System.Drawing.Size(75, 23)
        Me.btnAdlogin.TabIndex = 6
        Me.btnAdlogin.Text = "login"
        Me.btnAdlogin.UseVisualStyleBackColor = True
        '
        'tabUser
        '
        Me.tabUser.Controls.Add(Me.btnuserexit)
        Me.tabUser.Controls.Add(Me.btnUserregister)
        Me.tabUser.Controls.Add(Me.btnUserlogin)
        Me.tabUser.Location = New System.Drawing.Point(4, 22)
        Me.tabUser.Name = "tabUser"
        Me.tabUser.Padding = New System.Windows.Forms.Padding(3)
        Me.tabUser.Size = New System.Drawing.Size(353, 202)
        Me.tabUser.TabIndex = 0
        Me.tabUser.Text = "Users"
        Me.tabUser.UseVisualStyleBackColor = True
        '
        'btnuserexit
        '
        Me.btnuserexit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.btnuserexit.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnuserexit.Location = New System.Drawing.Point(30, 163)
        Me.btnuserexit.Name = "btnuserexit"
        Me.btnuserexit.Size = New System.Drawing.Size(75, 23)
        Me.btnuserexit.TabIndex = 3
        Me.btnuserexit.Text = "Exit"
        Me.btnuserexit.UseVisualStyleBackColor = True
        '
        'btnUserregister
        '
        Me.btnUserregister.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.btnUserregister.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnUserregister.Location = New System.Drawing.Point(30, 109)
        Me.btnUserregister.Name = "btnUserregister"
        Me.btnUserregister.Size = New System.Drawing.Size(75, 23)
        Me.btnUserregister.TabIndex = 2
        Me.btnUserregister.Text = "Register"
        Me.btnUserregister.UseVisualStyleBackColor = True
        '
        'btnUserlogin
        '
        Me.btnUserlogin.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnUserlogin.Location = New System.Drawing.Point(30, 49)
        Me.btnUserlogin.Name = "btnUserlogin"
        Me.btnUserlogin.Size = New System.Drawing.Size(75, 23)
        Me.btnUserlogin.TabIndex = 1
        Me.btnUserlogin.Text = "Login"
        Me.btnUserlogin.UseVisualStyleBackColor = True
        '
        'tabAdmin
        '
        Me.tabAdmin.Controls.Add(Me.tabUser)
        Me.tabAdmin.Controls.Add(Me.tabAdimn)
        Me.tabAdmin.Location = New System.Drawing.Point(29, 64)
        Me.tabAdmin.Name = "tabAdmin"
        Me.tabAdmin.SelectedIndex = 0
        Me.tabAdmin.Size = New System.Drawing.Size(361, 228)
        Me.tabAdmin.TabIndex = 0
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(458, 304)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.tabAdmin)
        Me.Name = "Form1"
        Me.Text = "Vertinary Hospital"
        Me.tabAdimn.ResumeLayout(False)
        Me.tabAdimn.PerformLayout()
        Me.tabUser.ResumeLayout(False)
        Me.tabAdmin.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As Label
    Friend WithEvents tabAdmin As TabControl
    Friend WithEvents btnUserlogin As Button
    Friend WithEvents btnUserregister As Button
    Friend WithEvents btnuserexit As Button
    Friend WithEvents tabUser As TabPage
    Friend WithEvents btnAdlogin As Button
    Friend WithEvents btnAdexit As Button
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents txtAdusername As TextBox
    Friend WithEvents txtAdpassword As TextBox
    Friend WithEvents tabAdimn As TabPage
End Class
