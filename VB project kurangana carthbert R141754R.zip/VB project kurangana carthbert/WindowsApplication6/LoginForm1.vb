﻿Imports MySql.Data.MySqlClient
Public Class frmuserlogin

    ' TODO: Insert code to perform custom authentication using the provided username and password 
    ' (See http://go.microsoft.com/fwlink/?LinkId=35339).  
    ' The custom principal can then be attached to the current thread's principal as follows: 
    '     My.User.CurrentPrincipal = CustomPrincipal
    ' where CustomPrincipal is the IPrincipal implementation used to perform authentication. 
    ' Subsequently, My.User will return identity information encapsulated in the CustomPrincipal object
    ' such as the username, display name, etc.
    'Represents an SQL statement or stored procedure to execute against a data source.
    Dim cmd As New MySqlCommand
    Dim da As New MySqlDataAdapter
    'declare conn as connection and it will now a new connection because 
    'it is equal to Getconnection Function
    Dim con As MySqlConnection = userconn()

    Public Function userconn() As MySqlConnection
        Return New MySqlConnection("server=localhost;userid=root;password=cazzy;database=vertinary_db")

    End Function

    Private Sub OK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK.Click
        Dim sql As String
        Dim publictable As New DataTable
        Try
            'check if the textbox is equal to nothing then it will display the message below!.
            If txtuname.Text = "" And txtpass.Text = "" Then
                MsgBox("Password or Username Incorrect!")

            Else
                sql = "select * from animal_owner where username ='" & txtuname.Text & "' and password = '" & txtpass.Text & "'"
                'bind the connection and query
                With cmd
                    .Connection = con
                    .CommandText = sql
                End With
                da.SelectCommand = cmd
                da.Fill(publictable)
                'check if theres a result by getting the count number of rows
                If publictable.Rows.Count > 0 Then


                    Dim username1, password1 As String

                    If username1 = txtuname.Text And password1 = txtpass.Text Then





                        txtuname.Text = ""
                        txtpass.Text = ""





                    Else
                        MsgBox("You are login!")

                        txtuname.Text = ""
                    txtpass.Text = ""

                End If

                Else
                MsgBox("enter correct username and password!")
                    txtuname.Text = ""
                    txtpass.Text = ""
                End If

                da.Dispose()
            End If

        Catch ex As Exception
            MsgBox(ex.Message)

        End Try
        con.Clone()
    End Sub

    Private Sub Cancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel.Click
        Me.Close()
    End Sub

    Private Sub frmuserlogin_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class
