﻿Imports MySql.Data.MySqlClient


Public Class frmUserRegistare
    Private Sub btnregistar_Click(sender As Object, e As EventArgs) Handles btnregistar.Click


        If txtname.Text = "" Then
            MsgBox("please enter name")
            txtname.Focus()
        End If
        If txtusername.Text = "" Then
            MsgBox("please enter username")
            txtusername.Focus()
        End If
        If txtpassword.Text = "" Then
            MsgBox("please enter password")



            txtusername.Focus()
        End If
        If txtpassword.TextLength < 4 Then
            MsgBox("please password must be more than 5 letters")
            txtpassword.Focus()
        End If
        If txtrepassword.Text = txtpassword.Text Then
            MsgBox("password does not match")
        End If

        If radmale.Checked = False And radfemale.Checked = False Then
            MsgBox("enter you email")
        End If
        If combAnimal.Text = "" Then
            MsgBox("please choose animal")
        End If

        vet.SaveData()

    End Sub

    Private Sub btnexit_Click(sender As Object, e As EventArgs) Handles btnexit.Click
        Me.Hide()
    End Sub

    Private Sub chckOption_SelectedIndexChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub FrmRegister_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim CommandObject As MySqlCommand
        Dim sqlString As String
        Dim DataReader As MySqlDataReader
        sqlString = "Select * FROM animal_owner"
        CommandObject = New MySqlCommand(sqlString, VetConnection())
        DataReader = CommandObject.ExecuteReader
        While (DataReader.Read())
            ''  SaveData.Items.Add(DataReader.GetString("name"))
        End While
    End Sub
End Class